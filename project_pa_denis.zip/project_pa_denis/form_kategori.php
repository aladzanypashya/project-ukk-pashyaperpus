<?php include "auth.php"; wajib_staff(); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Data Kategori</title>
</head>
<body>

<h1>Tambah Data Kategori</h1>

<form action="simpan_kategori.php" method="post">

  <label>Kode Kategori:</label><br>
  <input type="text" name="kode_kategori" required><br><br>

  <label>Nama Kategori:</label><br>
  <input type="text" name="nama_kategori" required><br><br>

  <button type="submit">Simpan</button>
  <button type="reset">Reset</button>

  <a href="tampil_kategori.php">
    <button type="button">Kembali</button>
  </a>

</form>

</body>
</html>
